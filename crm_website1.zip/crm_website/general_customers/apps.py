from django.apps import AppConfig


class GeneralCustomersConfig(AppConfig):
    name = 'general_customers'
