from django.db import models

class Customer(models.Model):
    cid = models.CharField()
    rid = models.CharField()
    mid = models.CharField()
    eid = models.CharField()
    DOP = models.DateField()
    CExpiry = models.DateField()

def set_CExpiry(self):
     self.CExpiry=date self.DOP + integer '30'

