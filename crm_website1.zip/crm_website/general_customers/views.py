from django.shortcuts import render, redirect, get_object_or_404

def gcustomers(request):
    return render(request, 'general_customer.html')

