
from django.shortcuts import render
from django import forms
from general_customers.models import Customer, Employee, Resource, Registration

import math

count = Customer.objects.filter(eid='e001').count()

emp_list = Employee.objects.filter(eid='e001')
for emp in emp_list:
    sales = emp.sales

product = Resource.objects.all().count()

ec2 = Customer.objects.filter(rid='r001').count()
quick_sight = Customer.objects.filter(rid='r002').count()
lambd = Customer.objects.filter(rid='r003').count()
s3 = Customer.objects.filter(rid='r004').count()
rds = Customer.objects.filter(rid='r005').count()

tot = ec2 + quick_sight + lambd +s3 + rds

ec2 = math.floor((ec2/tot)*100)
quick_sight = math.floor((quick_sight/tot)*100)
lambd = math.floor((lambd/tot)*100)
s3 = math.floor((s3/tot)*100)
rds = math.floor((rds/tot)*100)

list=Customer.objects.filter(eid='e001')
nameid=[]
rids=[]
status=[]

for cust in list:
     nameid.append(cust.cid.firstname)
     rids.append(cust.rid.rname)
     status.append(cust.status)



def index(request):
    return render(request, 'dashboard.html', {
        'count': count,
        'sales': sales,
        'product': product,
        'ec2': ec2,
        'quick_sight': quick_sight,
        'lambd': lambd,
        's3': s3,
        'rds': rds,
        'nameid0': nameid[0],
        'rids0': rids[0],
        'status0': status[0],
        'nameid1': nameid[1],
        'rids1': rids[1],
        'status1': status[1]

    })
def privacy(request):
    return render(request, 'privacy.html')

def get_id(request):

    # if this is a POST request we need to process the form data
    if request.method == 'POST':
    # create a form instance and populate it with data from the request:
        form = NameForm(request.POST)
    # check whether it's valid:
    if form.is_valid():
        # process the data in form.cleaned_data as required
        locationGo = "/thanks/"
        template = loader.get_template("app/thanks.html")

        return HttpResponse(template.render({'name': 'name'}, request))



