from django.shortcuts import render, redirect, get_object_or_404
from general_customers.models import Visitors

list=Visitors.objects.all()

name=[]
visitor=[]
time=[]

for v in list:
     name.append(v.product)
     visitor.append(v.visitors)
     time.append(v.avg_time)


def g_customers(request):
    return render(request, 'general_customer.html', {
        'name0': name[0],
        'visitor0': visitor[0],
        'time0': time[0],
        'name1': name[1],
        'visitor1': visitor[1],
        'time1': time[1],
        'name2': name[2],
        'visitor2': visitor[2],
        'time2': time[2],
        'name3': name[3],
        'visitor3': visitor[3],
        'time3': time[3],
        'name4': name[4],
        'visitor4': visitor[4],
        'time4': time[4],
    })

