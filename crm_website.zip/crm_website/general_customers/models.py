from django.db import models

class Registration(models.Model):
    cid = models.CharField(primary_key=True, max_length=20)
    firstname = models.CharField(db_column='firstName', max_length=20)  # Field name made lowercase.
    lastname = models.CharField(db_column='lastName', max_length=20)  # Field name made lowercase.
    phoneno = models.BigIntegerField(db_column='phoneNo')  # Field name made lowercase.
    age = models.IntegerField()
    gender = models.TextField()  # This field type is a guess.
    cemailid = models.CharField(db_column='cEmailid', max_length=128)  # Field name made lowercase.
    loc = models.CharField(max_length=20)

    class Meta:

        db_table = 'registration'

class Employee(models.Model):
    eid = models.CharField(primary_key=True, max_length=20)
    efname = models.CharField(db_column='EFName', max_length=20)  # Field name made lowercase.
    elname = models.CharField(db_column='ELName', max_length=20)  # Field name made lowercase.
    eemailid = models.CharField(db_column='EEmailid', max_length=50)  # Field name made lowercase.
    pass_field = models.CharField(db_column='pass', max_length=50)  # Field renamed because it was a Python reserved word.
    sales = models.IntegerField()

    class Meta:

        db_table = 'employee'

    def get_sales(self):
        return self.sales


class Login(models.Model):
    eid = models.ForeignKey(Employee, models.DO_NOTHING, db_column='eid', primary_key=True)
    efname = models.CharField(db_column='EFName', max_length=20)  # Field name made lowercase.
    pass_field = models.CharField(db_column='pass', max_length=20)  # Field renamed because it was a Python reserved word.

    class Meta:

        db_table = 'login'

class Resource(models.Model):
    rid = models.CharField(primary_key=True, max_length=20)
    rname = models.CharField(max_length=20)

    class Meta:

        db_table = 'Resource'


class Membership(models.Model):
    mid = models.CharField(primary_key=True, max_length=20)
    rid = models.ForeignKey(Resource, models.DO_NOTHING, db_column='rid')
    mname = models.CharField(max_length=20)
    mexpiry = models.IntegerField()
    price = models.IntegerField()

    class Meta:

        db_table = 'membership'

class Customer(models.Model):
    cid = models.ForeignKey('Registration', models.DO_NOTHING, db_column='cid')
    rid = models.ForeignKey('Resource', models.DO_NOTHING, db_column='rid')
    mid = models.ForeignKey('Membership', models.DO_NOTHING, db_column='mid')
    dop = models.DateField()
    eid = models.ForeignKey('Employee', models.DO_NOTHING, db_column='eid', blank=True, null=True)
    cexpiry = models.DateField()
    status=models.CharField(max_length=20, default='pending')

    class Meta:

        db_table = 'customer'

class Visitors(models.Model):
    product = models.CharField(db_column='product', max_length=20)  # Field name made lowercase.
    visitors= models.CharField(db_column='visitors', max_length=20)  # Field name made lowercase.
    avg_time = models.CharField(db_column='avg_time', max_length=50)  # Field name made lowercase.


    class Meta:

        db_table = 'visitors'






