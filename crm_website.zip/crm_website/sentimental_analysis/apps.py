from django.apps import AppConfig


class SentimentalAnalysisConfig(AppConfig):
    name = 'sentimental_analysis'
