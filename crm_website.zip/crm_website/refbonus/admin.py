from django.contrib import admin

# Register your models here.
admin.site.site_url = 'http://127.0.0.1:8000/refbonus/'
