from django.apps import AppConfig


class RefbonusConfig(AppConfig):
    name = 'refbonus'
